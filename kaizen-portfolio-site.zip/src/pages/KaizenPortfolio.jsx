import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { motion } from "framer-motion";

const data = [
  { name: "Session 1", value: 3 },
  { name: "Session 2", value: 7 },
  { name: "Session 3", value: 5 },
  { name: "Session 4", value: 9 }
];

export default function KaizenPortfolio() {
  return (
    <main className="p-6 grid gap-6 grid-cols-1 md:grid-cols-2">
      <motion.h1 className="text-4xl font-bold col-span-full" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        I Built an AI That Builds Smarter AI
      </motion.h1>

      <Card className="rounded-2xl shadow-md p-4">
        <CardContent>
          <h2 className="text-2xl font-semibold mb-2">Live Intelligence Stack</h2>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={data}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-md p-4">
        <CardContent>
          <h2 className="text-2xl font-semibold mb-2">Autonomous Architecture</h2>
          <p>
            Featuring self-diffing code intelligence, prompt fingerprinting, and strict output
            validation. Built with modular agents and real-time telemetry.
          </p>
          <Button className="mt-4">Explore Architecture</Button>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-md p-4 col-span-full">
        <CardContent>
          <h2 className="text-2xl font-semibold mb-2">Blog</h2>
          <ul className="list-disc ml-6 space-y-1">
            <li>How I Built a Self-Validating LLM Stack</li>
            <li>Lessons from Deploying Generative Agents</li>
            <li>Visualizing Evolving Intelligence</li>
          </ul>
        </CardContent>
      </Card>
    </main>
  );
}
